from django.shortcuts import render
import json
from django.http import HttpResponse
from django.http import HttpResponseRedirect
# from django.http.response import JsonResponse
from avmoo_app.models import AvbookAvmooDirector
from avmoo_app.models import AvbookAvmooStar
from avmoo_app.models import AvbookAvmooMovie
from avmoo_app.models import AvbookAvmooDirector
from django.conf import settings
from avmoo_app.forms import StarMovieForm

# Create your views here.
def test(request):
    resp = {'errorcode': 100, 'detail': 'Get success'}
    return HttpResponse(json.dumps(resp), content_type="application/json")

def dirs_list(request):
    dirs = AvbookAvmooDirector.objects.all()

    context_dict = {'name':"eric",'base_dir':settings.BASE_DIR,'dirs':dirs}
    response = render(request, 'index.html', context_dict)
    return response

def stars_list(request):
    stars = AvbookAvmooStar.objects.all()

    context_dict = {'stars':stars}
    response = render(request, 'stars.html', context_dict)
    return response   
    # return HttpResponse(json.dumps(context_dict), content_type="application/json")

def stars_json(request):
    stars = AvbookAvmooStar.objects.all()[:100]
    json_dict = {}
    json_list = {}
    for star in stars:
        json_dict = {}
        json_dict['name'] = star.star_name
        json_dict['birthday'] = star.star_birthday
        json_dict['star_pic'] = 'https://jp.netcdn.space/mono/actjpgs/' + star.star_pic
        num = star.code_10
        json_list[num] = json_dict

    # response = render(request, 'stars.html', json_dict)
    # return response      
    return HttpResponse(json.dumps(json_list), content_type="application/json")

def star(request):
    # form = StarMovieForm()
    if request.method == 'POST':
        form = StarMovieForm(request.POST)
        if form.is_valid():
            # return HttpResponseRedirect('/star_find/')
            # pass
            name = request.POST.get('star_name')
            print("name:" + name)
            
            movie_list = find_star_movie_list(name)
            # print(movie_list)
            return render(request,'star.html',{'form':form,'name':name,'movie_list':movie_list})
    else:
        form = StarMovieForm()
    return render(request,'star.html',{'form':form})

def find_star_movie_list(name):
    star = AvbookAvmooStar.objects.get(star_name=name)
    star_id = star.code_36
    # print(star_id)
    if star_id is not None:
        star_no = '[' + star_id + ']'
    # print(star_no )
        movie_list = AvbookAvmooMovie.objects.filter(jav_idols=star_no).order_by('-code_10')

        movie_dict = {}
        movie_json = {}
        movie_tab = []
        for movie in movie_list:
            movie_dict = {}
            movie_dict['censored_id'] = movie.censored_id
            if len(movie.movie_title) >= 40:
                movie_dict['movie_title'] = movie.movie_title[0:49]
            else:
                movie_dict['movie_title'] = movie.movie_title
            # movie_dict['movie_title'] = movie.movie_title
            movie_dict['release_date'] = movie.release_date
            num = movie.code_10
            # num = 'data'
            movie_json[num] = movie_dict
            movie_tab.append(movie_dict)

        # print(movie_tab)
        return movie_tab
    else:
        return None

def movie_detail(request, movie_no):
    movies = AvbookAvmooMovie.objects.filter(censored_id=movie_no)
    print(movies)
    json_dict = {}
    # json_list = {}

    # json_dict = {}
    for movie in movies:
        json_dict['censored_id'] = movie.censored_id
        json_dict['movie_title'] = movie.movie_title
        json_dict['movie_pic_cover'] = 'https://jp.netcdn.space/digital/video/' + movie.movie_pic_cover  
        json_dict['release_date'] = movie.release_date
        json_dict['movie_length'] = movie.movie_length
        if(movie.director):
            dir = AvbookAvmooDirector.objects.get(code_36=movie.director)
            json_dict['director'] = dir.director_name
        json_dict['studio'] = movie.studio
        json_dict['label'] = movie.label
        json_dict['series'] = movie.series
        json_dict['genre'] = movie.genre
        json_dict['jav_idols'] = movie.jav_idols
        json_dict['sample_dmm'] = movie.sample_dmm

    return HttpResponse(json.dumps(json_dict), content_type="application/json")