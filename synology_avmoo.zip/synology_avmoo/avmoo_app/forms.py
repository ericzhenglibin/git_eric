from django import forms
from avmoo_app.models import AvbookAvmooMovie
from avmoo_app.models import AvbookAvmooStar

class StarMovieForm(forms.ModelForm):
    star_name = forms.CharField(max_length=128,help_text="input star name here.")

    class Meta:
        model = AvbookAvmooStar
        fields = ('star_name',)