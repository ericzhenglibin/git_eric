
from django.db import models


class AvbookAvmooDirector(models.Model):
    code_36 = models.CharField(primary_key=True, max_length=5)
    director_name = models.CharField(max_length=256, blank=True, null=True)
    code_10 = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_director'


class AvbookAvmooGenre(models.Model):
    genre_code = models.CharField(primary_key=True, max_length=11)
    genre_dsce = models.CharField(max_length=64, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_genre'


class AvbookAvmooLabel(models.Model):
    code_36 = models.CharField(primary_key=True, max_length=5)
    label_name = models.CharField(max_length=256, blank=True, null=True)
    code_10 = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_label'


class AvbookAvmooMovie(models.Model):
    code_10 = models.IntegerField(blank=True, null=True)
    code_36 = models.CharField(primary_key=True, max_length=6)
    censored_id = models.CharField(max_length=64)
    movie_title = models.CharField(max_length=512, blank=True, null=True)
    movie_pic_cover = models.CharField(max_length=128, blank=True, null=True)
    release_date = models.CharField(max_length=32, blank=True, null=True)
    movie_length = models.CharField(max_length=32, blank=True, null=True)
    director = models.CharField(db_column='Director', max_length=12, blank=True, null=True)  # Field name made lowercase.
    studio = models.CharField(db_column='Studio', max_length=12, blank=True, null=True)  # Field name made lowercase.
    label = models.CharField(db_column='Label', max_length=12, blank=True, null=True)  # Field name made lowercase.
    series = models.CharField(db_column='Series', max_length=256, blank=True, null=True)  # Field name made lowercase.
    genre = models.CharField(db_column='Genre', max_length=256, blank=True, null=True)  # Field name made lowercase.
    jav_idols = models.CharField(db_column='JAV_Idols', max_length=256, blank=True, null=True)  # Field name made lowercase.
    sample_dmm = models.IntegerField(blank=True, null=True)
    have_mg = models.IntegerField(blank=True, null=True)
    have_file = models.IntegerField(blank=True, null=True)
    have_hd = models.IntegerField(blank=True, null=True)
    have_sub = models.IntegerField(blank=True, null=True)
    have_hdbtso = models.IntegerField(blank=True, null=True)
    have_mgbtso = models.IntegerField(blank=True, null=True)
    have_file2 = models.IntegerField(blank=True, null=True)
    favorite = models.IntegerField(blank=True, null=True)
    wanted = models.IntegerField(blank=True, null=True)
    watched = models.IntegerField(blank=True, null=True)
    owned = models.IntegerField(blank=True, null=True)
    visited = models.IntegerField(blank=True, null=True)
    blogjav_img = models.CharField(max_length=128, blank=True, null=True)
    magnet_date = models.DateTimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_movie'


class AvbookAvmooSeries(models.Model):
    code_36 = models.CharField(primary_key=True, max_length=10)
    series_name = models.CharField(max_length=256, blank=True, null=True)
    code_10 = models.PositiveIntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_series'


class AvbookAvmooStar(models.Model):
    code_36 = models.CharField(primary_key=True, max_length=5)
    star_name = models.CharField(max_length=128, blank=True, null=True)
    star_birthday = models.CharField(max_length=64, blank=True, null=True)
    star_age = models.IntegerField(blank=True, null=True)
    star_cupsize = models.CharField(max_length=8, blank=True, null=True)
    star_height = models.IntegerField(blank=True, null=True)
    star_bust = models.IntegerField(blank=True, null=True)
    star_waist = models.IntegerField(blank=True, null=True)
    star_hip = models.IntegerField(blank=True, null=True)
    hometown = models.CharField(max_length=128, blank=True, null=True)
    hobby = models.CharField(max_length=512, blank=True, null=True)
    star_pic = models.CharField(max_length=64, blank=True, null=True)
    favorite = models.IntegerField(blank=True, null=True)
    file_num = models.IntegerField(blank=True, null=True)
    code_10 = models.PositiveIntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_star'


class AvbookAvmooStudio(models.Model):
    code_36 = models.CharField(primary_key=True, max_length=10)
    studio_name = models.CharField(max_length=256, blank=True, null=True)
    code_10 = models.PositiveIntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'avbook_avmoo_studio'

