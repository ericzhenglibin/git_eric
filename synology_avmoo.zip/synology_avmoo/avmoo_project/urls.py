"""avmoo_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from avmoo_app import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('test/', views.test, name='test'),
    path('dirs/', views.dirs_list, name='dirs_list'),
    path('stars/', views.stars_list, name='stars_list'),
    path('stars2/', views.stars_json, name='stars_json'),
    path('star/', views.star, name='star'),
    path('movie/<movie_no>/', views.movie_detail, name='move_detail'),
    path('', views.star, name='star'),
    # path('star_find/', views.star, name='star'),
]
